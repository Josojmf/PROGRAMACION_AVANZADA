package pattern;

/**
 * 
 *  Service - Class that provides some functionality to work with Integer arrays
 *
 */
public class Service {

	Service(){

	}

	/**
	 * Function to generate random integers inside a defined range (limits included)
	 * 
	 * @param start		Lower limit of the range (included)
	 * @param end		Upper limit of the range (included)
	 * @param n			Number of random integers to generate
	 * @return			Returns an Integer array with the generated random numbers [start, end]
	 */
	Integer [] dataGeneration(int start, int end, int n) {
		Integer[] aux = new Integer[n];
		for(int i=0;i<n;i++) {
			aux[i] = (Integer)(int)(Math.floor(Math.random()*(end-start+1)+start));
		}
		return aux;
	}

	/**
	 * Function to slide an Integer array given the start and end index (both included)
	 * @param start		Initial index of the slide from the given array (included)
	 * @param end		Final index of the slide from the given array (included)
	 * @param array		Initial array given for slicing
	 * @return			Sliced Integer array with [end-start+1] elements
	 */
	Integer [] dataSelection(int start, int end, Integer [] array) {
		if(end>array.length-1){
			end = array.length-1;
		}
		Integer[] aux = new Integer[end-start+1];
		for (int i = 0; i < aux.length; i++) {
			aux[i] = array[start + i];
		}
		return aux;
	}
}