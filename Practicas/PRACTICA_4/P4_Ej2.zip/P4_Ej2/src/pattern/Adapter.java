package pattern;

import java.util.ArrayList;

public class Adapter {

	public Adapter(Service servicioA) {
		// TODO Auto-generated constructor stub
	}
	//Funcion que se encarga de llamar a la funcion dataGeneration de service y saca el resultado de un 
	//array estatico y lo guarda en un array list  

	public ArrayList<Integer> dataGeneration(int i, int j, int k) {
		ArrayList<Integer> AL= new ArrayList<Integer>();
		Service service = new Service();
		Integer[] arr=service.dataGeneration(i, j, k);
			for(int l=0;l<arr.length;l++) {
				AL.add(arr[l]);
				
			}
	
		return AL;
	}
	//Funcion que se encarga de llamar a la funcion dataSelection de service
	//primero guardando los datos en un array estatico para que la funcion pueda operar
	//y luego vuelve a guardar todos los datos en un array list para que el codigo del cliente pueda operar con ellos

	public ArrayList<Integer> dataSelection(int i, int j, ArrayList<Integer> numbers) {
		ArrayList<Integer> AL= new ArrayList<Integer>();
		Integer arr[]= new Integer[numbers.size()];
		Service service = new Service();
			for(int l=0;l<numbers.size();l++) {
			arr[l]=numbers.get(l);	
				
			}
			arr=service.dataSelection(i, j, arr);
			for(int l=0;l<arr.length;l++) {
				AL.add(arr[l]);
				
			}
	
		return AL;
			
	}

}
