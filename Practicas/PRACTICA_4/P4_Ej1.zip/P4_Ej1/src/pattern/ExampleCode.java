package pattern;

public class ExampleCode {
	public static void main(String[] args) {
		Client ClienteA,ClienteB;
		BaseDatos BD1 = null , BD2 = null ;
		
		// Secci�n modificable, s�lo estas 2 l�neas
		
		BD1 = BaseDatos.getInstance();//se crea el objeto a traves de la funcion para solo crear una instancia 
		BD2 = BaseDatos.getInstance();
		
		
		ClienteA = new Client(BD1);
		ClienteB = new Client(BD2);
		
		//Comprobar que al implementar el Singleton, el resultado es true
		System.out.println(ClienteA.getBD()==ClienteB.getBD());
	}
}
