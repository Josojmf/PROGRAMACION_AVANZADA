package pattern;

import java.util.ArrayList;

public class BaseDatos {
	
	private static BaseDatos instance;
	private ArrayList<String> Personas;
	
	private BaseDatos(){
		Personas = new ArrayList<String>();
	}
	
	public void add(String name) {
		Personas.add(name);
	}
	
	public static BaseDatos getInstance() {
		if(instance==null) {
			instance=new BaseDatos();
		}
		return instance;
	}
}
