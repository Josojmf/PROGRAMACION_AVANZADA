package pattern;

public class Client {
	private BaseDatos BD;//Objeto instancia para comprobar si s�lo hay un objeto creado 

	Client(BaseDatos BD){
		this.BD = BD;
	}

	public void addPerson(String name) { //Constructor privado para que solo se pueda acceder a el a traves de la funcion getInstance(); 
		BD.add(name);
	}

	public BaseDatos getBD() {    //funcion que comprueba si el programa ya ha creado una instancia previa de este tipo de objeto, si ya esta creado devuelve el anterior 
		return BD;
	}
}
